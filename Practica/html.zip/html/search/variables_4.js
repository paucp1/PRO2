var searchData=
[
  ['nom_205',['nom',['../class_problema.html#a6f588164528c2faa97c8c82df899f655',1,'Problema::nom()'],['../class_sesion.html#a1f194fbf7af8c51693d247cb2653644d',1,'Sesion::nom()'],['../class_usuario.html#a035b893ab6fece7c1a085277e0bf92a7',1,'Usuario::nom()']]]
];
