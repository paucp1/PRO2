var searchData=
[
  ['actualizar_5fconjuntos_0',['actualizar_conjuntos',['../class_usuario.html#a9bb517eb0e805bf8cfccdced993b8841',1,'Usuario']]],
  ['actualizar_5festadisticas_1',['actualizar_estadisticas',['../class_problema.html#afe7008c2e4b54a2657859eabf40f8ee6',1,'Problema::actualizar_estadisticas()'],['../class_usuario.html#a3101e6e7a81459c65570c1439ab9f12a',1,'Usuario::actualizar_estadisticas()']]],
  ['anadir_5fcurso_2',['anadir_curso',['../class_cjt__cursos.html#a18aee3066208178bdc2f2adfe0fa3977',1,'Cjt_cursos']]],
  ['anadir_5fproblema_3',['anadir_problema',['../class_cjt__problemas.html#adbf73998cea235146dcde55ceaf52d77',1,'Cjt_problemas']]],
  ['anadir_5fsesion_4',['anadir_sesion',['../class_cjt__sesiones.html#afcc14b01ab03020a2daaaf310ba2e33a',1,'Cjt_sesiones']]],
  ['anadir_5fusuario_5',['anadir_usuario',['../class_cjt__usuarios.html#a0c0173844494567a272f9ce1838ee235',1,'Cjt_usuarios']]]
];
