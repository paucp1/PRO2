var searchData=
[
  ['problemas_5fcurso_206',['problemas_curso',['../class_curso.html#a44860b6cc3369ae81011cb8f78a31c22',1,'Curso']]],
  ['problemas_5fintentados_207',['problemas_intentados',['../class_usuario.html#a5484a08ce9aeabef98074c738f58b00a',1,'Usuario']]],
  ['problemas_5fresueltos_208',['problemas_resueltos',['../class_usuario.html#a071e5ec2eb6d95e32d3f42a48cf92f8d',1,'Usuario']]]
];
