var searchData=
[
  ['usu_5fcompletado_211',['usu_completado',['../class_curso.html#aed392615b10d39b04a3d81014c72aa4a',1,'Curso']]],
  ['usu_5finscritos_212',['usu_inscritos',['../class_curso.html#a1dc86818f6fc05430a377563a37ee73a',1,'Curso']]]
];
