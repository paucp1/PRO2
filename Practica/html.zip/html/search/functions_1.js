var searchData=
[
  ['borrar_5fproblema_5fusuario_134',['borrar_problema_usuario',['../class_cjt__problemas.html#ac61ba1a3af60ec7eb95c6caf1e3bcea0',1,'Cjt_problemas']]]
];
