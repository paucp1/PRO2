var searchData=
[
  ['nombre_177',['nombre',['../class_problema.html#a4218019c4c08f913a84e965e194e3c2c',1,'Problema::nombre()'],['../class_sesion.html#a46599715cc434ba5e8f5a177c6a20e2d',1,'Sesion::nombre()'],['../class_usuario.html#abe47b92a174044904346f5d3cca66754',1,'Usuario::nombre()']]],
  ['numero_5fcursos_178',['numero_cursos',['../class_cjt__cursos.html#a9bdd4af9744c8dd61966c266caac10a5',1,'Cjt_cursos']]],
  ['numero_5fproblemas_179',['numero_problemas',['../class_cjt__problemas.html#ae7c40c56d39772dc8298eefad44396ba',1,'Cjt_problemas::numero_problemas()'],['../class_sesion.html#accbe4daeb470dbd8a38caddf5b4c2578',1,'Sesion::numero_problemas()']]],
  ['numero_5fsesiones_180',['numero_sesiones',['../class_cjt__sesiones.html#aacf1d9128ba8fed6391ecc4828776017',1,'Cjt_sesiones']]],
  ['numero_5fusuarios_181',['numero_usuarios',['../class_cjt__usuarios.html#aaabb466a2bbe6bd5839719b38aac7e74',1,'Cjt_usuarios']]]
];
