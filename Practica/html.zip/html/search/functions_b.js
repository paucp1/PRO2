var searchData=
[
  ['ratio_187',['ratio',['../class_problema.html#a8b41092b4207375e9f1bb4e29b9d4535',1,'Problema']]]
];
