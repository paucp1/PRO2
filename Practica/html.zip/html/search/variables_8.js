var searchData=
[
  ['vec_5fses_213',['vec_ses',['../class_curso.html#a320f1609d85b087fe27c4dd713462aff',1,'Curso']]]
];
