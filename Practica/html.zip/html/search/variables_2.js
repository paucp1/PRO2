var searchData=
[
  ['e_5fcorrectos_200',['e_correctos',['../class_problema.html#af1211c32503dfee3680516f8ac04b588',1,'Problema']]],
  ['e_5frealizados_201',['e_realizados',['../class_problema.html#a7e64e10f2314cd23dd9d55662db6b3da',1,'Problema']]],
  ['envios_5ftotales_202',['envios_totales',['../class_usuario.html#a593cda8a1a1968ccbdb51599cd384d0a',1,'Usuario']]]
];
