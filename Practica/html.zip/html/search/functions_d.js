var searchData=
[
  ['usuario_191',['Usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()'],['../class_usuario.html#a12f869425496a01dc2bcdc3915eabd68',1,'Usuario::Usuario(const string &amp;id)']]],
  ['usuarios_5finscritos_192',['usuarios_inscritos',['../class_curso.html#a2785e9252ec2091cabbde6d17776258c',1,'Curso']]]
];
