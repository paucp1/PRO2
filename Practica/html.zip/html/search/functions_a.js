var searchData=
[
  ['problema_183',['Problema',['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema::Problema()'],['../class_problema.html#ad76fed3e8035fba55a05759d2d78b852',1,'Problema::Problema(const string &amp;id)']]],
  ['problema_5finicial_184',['problema_inicial',['../class_sesion.html#aae7fb071f2d4c07d0cfe16d0f4473df9',1,'Sesion']]],
  ['problema_5fsiguiente_185',['problema_siguiente',['../class_sesion.html#abb8305930a245f80d3fa45c60b7f92f4',1,'Sesion']]],
  ['problemas_5fcontenidos_186',['problemas_contenidos',['../class_sesion.html#a6466d460d230b668655de5d229ab5520',1,'Sesion']]]
];
