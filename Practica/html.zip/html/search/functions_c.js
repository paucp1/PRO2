var searchData=
[
  ['sesion_188',['Sesion',['../class_sesion.html#adf5a84efa8e2629b30ad89df74cfc0a2',1,'Sesion::Sesion()'],['../class_sesion.html#aded67c8b43df30fbb5ef9d682351b370',1,'Sesion::Sesion(const string &amp;id)']]],
  ['sesion_5fproblema_189',['sesion_problema',['../class_curso.html#a379374f8240f659a61eb164deff26867',1,'Curso']]],
  ['sesion_5fproblema_5fconj_190',['sesion_problema_conj',['../class_cjt__cursos.html#a205e32cff61f7d08df3c19fb75e4b8d6',1,'Cjt_cursos']]]
];
