var searchData=
[
  ['problema_78',['Problema',['../class_problema.html',1,'Problema'],['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema::Problema()'],['../class_problema.html#ad76fed3e8035fba55a05759d2d78b852',1,'Problema::Problema(const string &amp;id)']]],
  ['problema_2ecc_79',['Problema.cc',['../_problema_8cc.html',1,'']]],
  ['problema_2ehh_80',['Problema.hh',['../_problema_8hh.html',1,'']]],
  ['problema_5finicial_81',['problema_inicial',['../class_sesion.html#aae7fb071f2d4c07d0cfe16d0f4473df9',1,'Sesion']]],
  ['problema_5fsiguiente_82',['problema_siguiente',['../class_sesion.html#abb8305930a245f80d3fa45c60b7f92f4',1,'Sesion']]],
  ['problemas_5fcontenidos_83',['problemas_contenidos',['../class_sesion.html#a6466d460d230b668655de5d229ab5520',1,'Sesion']]],
  ['problemas_5fcurso_84',['problemas_curso',['../class_curso.html#a44860b6cc3369ae81011cb8f78a31c22',1,'Curso']]],
  ['problemas_5fintentados_85',['problemas_intentados',['../class_usuario.html#a5484a08ce9aeabef98074c738f58b00a',1,'Usuario']]],
  ['problemas_5fresueltos_86',['problemas_resueltos',['../class_usuario.html#a071e5ec2eb6d95e32d3f42a48cf92f8d',1,'Usuario']]],
  ['program_2ecc_87',['program.cc',['../program_8cc.html',1,'']]]
];
