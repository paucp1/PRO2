var searchData=
[
  ['borrar_5fproblema_5fusuario_6',['borrar_problema_usuario',['../class_cjt__problemas.html#ac61ba1a3af60ec7eb95c6caf1e3bcea0',1,'Cjt_problemas']]],
  ['bt_5fses_7',['bt_ses',['../class_sesion.html#a560ede65f9e4de7591c3e149d3132a37',1,'Sesion']]]
];
