var searchData=
[
  ['ident_203',['ident',['../class_curso.html#a8b63fd82b86802c58ae0ea08b4c373f0',1,'Curso']]],
  ['inscrito_204',['inscrito',['../class_usuario.html#a40419ea3f2038a888ed3ebcf7d5ac541',1,'Usuario']]]
];
